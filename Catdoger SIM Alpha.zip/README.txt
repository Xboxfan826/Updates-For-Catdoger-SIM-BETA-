Credit To The Main Creator @scratchlover501 The  Creator 
The Link To The Creator's Page Is Here.  https://scratch.mit.edu/users/scratchlover501/
(This Code Is Credited And Uploaded With The Creators Permission)
Enjoy ;)